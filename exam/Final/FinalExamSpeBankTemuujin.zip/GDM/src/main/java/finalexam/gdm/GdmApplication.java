package finalexam.gdm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GdmApplication {

    public static void main(String[] args) {
        SpringApplication.run(GdmApplication.class, args);
    }

}
